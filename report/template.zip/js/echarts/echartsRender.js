let echartsNum=0;const createEchartsDetail=(e,a,t)=>{e=`
            <div class="echart-detail-item">
              <div class="echart-detail-item-title">
                ${e}
              </div>
              <div class="echart-detail-item-content">
                ${0===a.length?"暂无数据":a}
              </div>
              </div>
            `;$(`#${t}-detail`).length?$(`#${t}-detail`).html(e):(a=`
              <div class="echart-detail" id='${t}-detail'>
                ${e}
              </div>
            `,$("#"+t).after(a))},resizeChartsArr=[],cardTitleArr=["漏洞攻击路径统计"],createEcharts=(i,e)=>{let r="echarts-"+(echartsNum+=1);var a=`<div class="echarts-box echarts-box-${i}"><div id='${r}' class="echart-item echart-item-${i}"/></div>`,a=($("#content").append(a),echarts.init(document.getElementById(r)));let t;switch(i){case"pie-graph":t=initHollowOptionPie(e);break;case"vertical-bar-graph":t=initVerticalOptionBar(e);break;case"horizontal-bar-graph":t=initHorizontalOptionBar(e);break;case"stacked-vertical-bar-graph":t=initStackedVerticalBar(e);break;case"multi-pie":t=initMultiPie(e);break;case"nightingle-rose":t=initNightingleRose(e)}if("nightingle-rose"===i){var c=(e.data||[]).sort((e,a)=>a.value-e.value).slice(0,1).map(e=>({name:e.key_verbose||e.key,content:(e.detail||"").replace(/\n+/g,"\n").replaceAll("\n","<br/>")}));if(Array.isArray(c)){const{name:s,content:e}=c[0];createEchartsDetail(s,e,r)}}"stacked-vertical-bar-graph"===i&&t.xAxis.data.length<4&&($(".echarts-box-stacked-vertical-bar-graph").find(".echart-item").css("max-width","60%"),a.resize()),a.setOption(t),a.on("click",a=>{var e,t;if(["nightingle-rose"].includes(i)&&({name:e,content:t}=a.data,createEchartsDetail(e,t,r)),a.data?.jump_link){let e=window.location.href.replace(window.location.hash,"");e+=(-1===e.indexOf("?")?"?":"&")+"jump_link="+a.data.jump_link,a.data?.access_vector&&(e+=(-1===e.indexOf("?")?"?":"&")+"access_vector="+a.data.access_vector),window.open(e)}}),resizeChartsArr.push({type:i,fun:a}),window.onresize=()=>{resizeChartsArr.map(e=>{e.fun.resize()})}};