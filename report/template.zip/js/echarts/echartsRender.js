let echartsNum=0;const createEchartsDetail=(e,a,t)=>{e=`
            <div class="echart-detail-item">
              <div class="echart-detail-item-title">
                ${e}
              </div>
              <div class="echart-detail-item-content">
                ${0===a.length?"暂无数据":a}
              </div>
              </div>
            `;$(`#${t}-detail`).length?$(`#${t}-detail`).html(e):(a=`
              <div class="echart-detail" id='${t}-detail'>
                ${e}
              </div>
            `,$("#"+t).after(a))},resizeChartsArr=[],cardTitleArr=["漏洞攻击路径统计"],createEcharts=(r,e)=>{let a;switch(r){case"pie-graph":a=initHollowOptionPie(e);break;case"vertical-bar-graph":a=initVerticalOptionBar(e);break;case"horizontal-bar-graph":a=initHorizontalOptionBar(e);break;case"stacked-vertical-bar-graph":a=initStackedVerticalBar(e);break;case"multi-pie":a=initMultiPie(e);break;case"nightingle-rose":a=initNightingleRose(e);break;case"e-chart":a=initEChart(e)}if(a){let i="echarts-"+(echartsNum+=1);var t=`<div class="echarts-box echarts-box-${r}"><div id='${i}' class="echart-item echart-item-${r}"/></div>`,t=($("#content").append(t),echarts.init(document.getElementById(i)));if("nightingle-rose"===r){var c=(e.data||[]).sort((e,a)=>a.value-e.value).slice(0,1).map(e=>({name:e.key_verbose||e.key,content:(e.detail||"").replace(/\n+/g,"\n").replaceAll("\n","<br/>")}));if(Array.isArray(c)){const{name:s,content:e}=c[0];createEchartsDetail(s,e,i)}}"stacked-vertical-bar-graph"===r&&a.xAxis.data.length<4&&($(".echarts-box-stacked-vertical-bar-graph").find(".echart-item").css("max-width","60%"),t.resize()),t.setOption(a),t.on("click",a=>{var e,t;if(["nightingle-rose"].includes(r)&&({name:e,content:t}=a.data,createEchartsDetail(e,t,i)),a.data?.jump_link){let e=window.location.href.replace(window.location.hash,"");e+=(-1===e.indexOf("?")?"?":"&")+"jump_link="+a.data.jump_link,a.data?.access_vector&&(e+=(-1===e.indexOf("?")?"?":"&")+"access_vector="+a.data.access_vector),window.open(e)}}),resizeChartsArr.push({type:r,fun:t}),window.onresize=()=>{resizeChartsArr.map(e=>{e.fun.resize()})}}};