let echartsNum=0;const createEchartsDetail=(e,t,a)=>{e=`
            <div class="echart-detail-item">
              <div class="echart-detail-item-title">
                ${e}
              </div>
              <div class="echart-detail-item-content">
                ${0===t.length?"暂无数据":t}
              </div>
              </div>
            `;$(`#${a}-detail`).length?$(`#${a}-detail`).html(e):(t=`
              <div class="echart-detail" id='${a}-detail'>
                ${e}
              </div>
            `,$("#"+a).after(t))},resizeChartsArr=[],cardTitleArr=["漏洞攻击路径统计"],createEcharts=(i,e)=>{let r="echarts-"+(echartsNum+=1);var t=`<div class="echarts-box echarts-box-${i}"><div id='${r}' class="echart-item echart-item-${i}"/></div>`,t=($("#content").append(t),echarts.init(document.getElementById(r)));let a;switch(i){case"pie-graph":a=initHollowOptionPie(e);break;case"vertical-bar-graph":a=initVerticalOptionBar(e);break;case"horizontal-bar-graph":a=initHorizontalOptionBar(e);break;case"multi-pie":a=initMultiPie(e);break;case"nightingle-rose":a=initNightingleRose(e)}if("nightingle-rose"===i){var c=(e.data||[]).sort((e,t)=>t.value-e.value).slice(0,1).map(e=>({name:e.key_verbose||e.key,content:(e.detail||"").replace(/\n+/g,"\n").replaceAll("\n","<br/>")}));if(Array.isArray(c)){const{name:n,content:e}=c[0];createEchartsDetail(n,e,r)}}t.setOption(a),t.on("click",t=>{var e,a;if(["nightingle-rose"].includes(i)&&({name:e,content:a}=t.data,createEchartsDetail(e,a,r)),t.data?.jump_link){let e=window.location.href.replace(window.location.hash,"");e+=(-1===e.indexOf("?")?"?":"&")+"jump_link="+t.data.jump_link,t.data?.access_vector&&(e+=(-1===e.indexOf("?")?"?":"&")+"access_vector="+t.data.access_vector),window.open(e)}}),resizeChartsArr.push({type:i,fun:t}),window.onresize=()=>{resizeChartsArr.map(e=>{e.fun.resize()})}};