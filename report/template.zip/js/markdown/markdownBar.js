let tocItems=[],tocifyIndex=0;const tocifyAdd=(e,s)=>{if(s<=4){var l="toc"+s+ ++tocifyIndex,n={anchor:l,level:s,text:e},s=tocItems;if(0===s.length)s.push(n);else{let l=s.slice(-1);if(n.level>l.level)for(let e=l.level+1;e<=2;e++){var r=l["children"];if(!r){l.children=[n];break}if(l=r.slice(-1),n.level<=l.level){r.push(n);break}}else s.push(n)}return l}},isOpenBarFun=(e,l)=>{$(`#${e}-`+l).hasClass("open")?($(`#${e}-`+l).removeClass("open").addClass("close"),$("."+e).css("display","block")):($(`#${e}-`+l).removeClass("close").addClass("open"),$("."+e).css("display","none"))},renderToc=(reset=()=>{tocItems=[],tocifyIndex=0},e=>{reset();let n=null,r="";return e.map((e,l)=>{var s=GetUniqueID();return 0<=(e?.text||"").search("合规风险详情")||0<=(e?.text||"").search("危漏洞详情")?(n=e.level,r=""+s,`<div class="level-${e.level} extend">
      <a id="${s}-${l}" class="open"
      onclick="isOpenBarFun('${s}',${l})"></a>
        <a href="#${e.anchor}" class="content">
            ${e.text}
            ${e?.children?renderToc(e.children):""}
        </a>
        </div>`):n&&n<e.level?`<div class="level-${e.level} ${r}" style="display:none;">
        <a href="#${e.anchor}">
            ${e.text}
            ${e?.children?renderToc(e.children):""}
        </a>
        </div>`:(n&&n>=e.level&&(n=null),`<div class="level-${e.level}">
        <a href="#${e.anchor}">
            ${e.text}
            ${e?.children?renderToc(e.children):""}
        </a>
        </div>`)})});