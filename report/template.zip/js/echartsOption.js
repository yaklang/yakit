let solidOptionPie = {
  title: {
    text: "Referer of a Website",
    left: "center",
  },
  tooltip: {
    trigger: "item",
  },
  legend: {
    orient: "vertical",
    left: "left",
  },
  series: [
    {
      name: "Access From",
      type: "pie",
      radius: "50%",
      data: [
        { value: 1048, name: "Search Engine" },
        { value: 735, name: "Direct" },
        { value: 580, name: "Email" },
        { value: 484, name: "Union Ads" },
        { value: 300, name: "Video Ads" },
      ],
      emphasis: {
        itemStyle: {
          shadowBlur: 10,
          shadowOffsetX: 0,
          shadowColor: "rgba(0, 0, 0, 0.5)",
        },
      },
    },
  ],
};
// 饼图
const initSolidOptionPie = (content) => {
  const { title, value, color } = content;
  // 数据构造
  return solidOptionPie;
};

let multiPie = {
  title: {
    text: "",
    left: "center",
  },
  tooltip: {},
  // legend: {
  //   top: "bottom",
  // },
  grid: {
    show: false,
  },
  yAxis: {
    min: 0,
    max: 3,
    minInterval: 1,
    splitLine: {
      show: true,
      lineStyle: {
        color: "rgba(163, 163, 163, 0.5)",
        type: "dashed",
      },
    },
    axisLabel: {
      show: false,
      color: "#A0A4AA",
    },
    axisLine: {
      show: true,
      lineStyle: {
        color: "rgba(65, 97, 128, 0.5)",
      },
    },
  },
  xAxis: {
    data: ["数据"],
    axisLabel: {
      color: "#A0A4AA",
    },
    axisLine: {
      show: true,
      lineStyle: {
        color: "rgba(65, 97, 128, 0.5)",
      },
    },
    axisTick: {
      alignWithLabel: true,
    },
  },
  series: [],
};

// 多层饼环
const initMultiPie = (content) => {
  const { name_verbose, name, data } = content;
  let newOptionPie = JSON.parse(JSON.stringify(multiPie));
  let series = [];
  if (Array.isArray(data)) {
    data.map((item, index) => {
      let symbolSize = 0;
      let height = 0;
      let numOrder = 7.3;
      let numOrder1 = 6.6;
      let color = "";
      let x = 0;
      let y = 0;
      switch (index) {
        case 0:
          symbolSize = (((270 / 10) * numOrder1) / 10) * numOrder1;
          height = (((1.5 / 10) * numOrder1) / 10) * numOrder1;
          color = "rgba(30, 136, 207, 0.7)";
          x = 500;
          y = 200;
          break;
        case 1:
          symbolSize = (270 / 10) * numOrder;
          height = (1.5 / 10) * numOrder;
          color = "rgba(30, 136, 207, 0.5)";
          x = 480;
          y = 118;
          break;
        case 2:
          symbolSize = 270;
          height = 1.5;
          color = "rgba(30, 136, 207, 0.3)";
          x = 460;
          y = 40;
          break;
      }
      series.push({
        name: item?.key_verbose || item?.key,
        z: 3 - index,
        labelLine: {
          show: true,
          length2: 60,
          lineStyle: {
            color: "rgba(30, 136, 207)",
          },
        },
        labelLayout: {
          x,
          y,
          align: "center",
          hideOverlap: true,
          moveOverlap: "shiftY",
        },
        label: {
          show: true,
          formatter: function (param) {
            return `${param.name}  ${param.data.value[2]}`;
          },
          position: "right",
          // minMargin: 2
        },
        type: "scatter",
        symbol: "circle",
        emphasis: {
          disable: false,
          scale: false, //不缩放
          scaleSize: 0, //为了防止失效直接设置未0
        },
        itemStyle: {
          normal: {
            color: new echarts.graphic.RadialGradient(0.5, 0, 1, [
              {
                offset: 0.0,
                color,
              },
              {
                offset: 1,
                color,
              },
            ]),
          },
        },
        data: [
          {
            symbolSize,
            name: item?.key_verbose || item?.key,
            value: [1, height, item.value],
          },
        ],
      });
    });
  }
  newOptionPie.tooltip.formatter = function (arg) {
    return arg.name + "   " + arg.data.value[2];
  };
  newOptionPie.series = series;
  newOptionPie.title.text = name_verbose || name;
  return newOptionPie;
};

let optionBar = {
  title: {
    text: "",
    left: "center",
  },
  tooltip: {
    trigger: "axis",
    axisPointer: {
      type: "shadow",
    },
  },
  xAxis: {
    type: "category",
    data: ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"],
  },
  yAxis: {
    type: "value",
  },
  series: [
    {
      data: [120, 200, 150, 80, 70, 110, 130],
      type: "bar",
    },
  ],
};

// 竖向柱状图
const initVerticalOptionBar = (content) => {
  let newOptionBar = JSON.parse(JSON.stringify(optionBar));
  if (content?.type_verbose === "通用KV") {
    const { name_verbose, name, data } = content;
    let title = [];
    let value = [];
    Array.isArray(data) &&
      data.map((item) => {
        title.push(item.key_verbose || item.key);
        value.push(item.value);
      });
    newOptionBar.title.text = name_verbose || name;
    newOptionBar.xAxis.data = title || [];
    newOptionBar.series[0].data = value || [];
  } else {
    const { title, value, color } = content;
    newOptionBar.xAxis.data = title || [];
    newOptionBar.series[0].data = value || [];
  }
  return newOptionBar;
};

// 横向柱状图
const initHorizontalOptionBar = (content) => {
  const { title, value, color } = content;
  let newOptionBar = JSON.parse(JSON.stringify(optionBar));
  newOptionBar.xAxis.type = "value";
  newOptionBar.yAxis.type = "category";
  return newOptionBar;
};

let nightingleRose = {
  title: {
    text: "Nightingale Chart",
    left: "center",
  },
  tooltip: {
    trigger: "item",
    formatter: "{a} <br/>{b} : {c} ({d}%)",
  },
  legend: {
    top: "bottom",
  },
  toolbox: {
    show: true,
    feature: {
      mark: { show: true },
    },
  },
  series: [
    {
      name: "Nightingale Chart",
      type: "pie",
      radius: [50, 150],
      center: ["50%", "50%"],
      roseType: "area",
      itemStyle: {
        borderRadius: 8,
      },
      data: [
        { value: 40, name: "rose 1" },
        { value: 38, name: "rose 2" },
        { value: 32, name: "rose 3" },
        { value: 30, name: "rose 4" },
        { value: 28, name: "rose 5" },
        { value: 26, name: "rose 6" },
        { value: 22, name: "rose 7" },
        { value: 18, name: "rose 8" },
      ],
    },
  ],
};

// 南丁格尔玫瑰图
const initNightingleRose = (content) => {
  const { name_verbose, name, data } = content;
  let newOption = JSON.parse(JSON.stringify(nightingleRose));
  // 构造"南丁格尔玫瑰图"伪数据
  let cacheSource = JSON.parse(JSON.stringify(data));
  // 当值为1大于总数三分之一时 一半隐藏一半显示
  if (data.length >= 6) {
    let index = data.filter((item) => item.value === 1).length;
    let limit = data.length / 3;
    let isShow = true;
    if (index > limit) {
      let newData = data.filter((item) => {
        if (item.value > 1) return true;
        else {
          isShow = !isShow;
          return isShow;
        }
      });
      cacheSource = JSON.parse(JSON.stringify(newData));
    }
  }
  // 3-6为四分之一扇
  if (cacheSource.length < 6) {
    newOption.series[0].center = ["30%", "66%"];
    let limitCount = cacheSource.length * 3;
    for (let index = 0; index < limitCount; index++) {
      cacheSource.push({
        isHide: true,
      });
    }
  }
  // 6-12为二分之一扇
  else if (cacheSource.length >= 6 && cacheSource.length <= 12) {
    newOption.series[0].startAngle = 180;
    newOption.series[0].center = ["50%", "70%"];
    newOption.legend = {
      show: false,
    };
    let limitCount = cacheSource.length;
    for (let index = 0; index < limitCount; index++) {
      cacheSource.push({
        isHide: true,
      });
    }
  }
  // 12-20为全扇 超出数据不显示
  else if (cacheSource.length > 12) {
    newOption.series[0].radius = [40, 120];
    newOption.legend = {
      show: false,
    };
    cacheSource = cacheSource.slice(0, 20);
  }

  const value = cacheSource
    .map((item) => {
      if (item?.isHide) {
        return {
          value: 0,
          name: "",
          label: {
            show: false,
          },
          labelLine: {
            show: false,
          },
        };
      } else {
        const description_zh = item.detail||""
        let str = ""
        str = description_zh.replace(/\n+/g, '\n').replaceAll("\n","<br/>")
        return {
          value: item.value,
          name: item.key_verbose || item.key,
          content: str,
        };
      }
    })
    .sort((a, b) => b.value - a.value);
  newOption.tooltip.formatter = (params) => {
    return `${params.data.name} : ${params.data.value} (${params.percent}%)`;
  };

  newOption.title.text = name_verbose || name;
  newOption.series[0].name = name_verbose || name;
  newOption.series[0].data = value || [];
  return newOption;
};
