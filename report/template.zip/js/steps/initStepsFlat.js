const initStepsFlat=({title:s,steps:e,current:d})=>{const l=e.length;let n='<div class="step-container">';return s&&(n+=`<h4>${s}</h4>`),n+='<div class="step-wrapper">',e.forEach((s,e)=>{var t=e<d,i=e===d;n+=`
      <div class="step-item ${t?"done":""} ${i?"current":""}">
        <div class="step-icon">${t?"✓":""}</div>
        <div class="step-label">${s}</div>
      </div>
    `,e<l-1&&(n+=`<div class="step-line ${e<d?"line-done":""}"></div>`)}),n+="</div></div>"};