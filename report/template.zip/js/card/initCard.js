let cacheCard={};const isOpenCardFun=(e,s)=>{$("#"+e).hasClass("open")?($("#"+e).removeClass("open").addClass("close"),$("#"+e).nextAll(".card-content").remove()):($("#"+e).removeClass("close").addClass("open"),$("#"+e).after(`
    <div class="card-content ${s?"card-content-bg":""}">
      ${cacheCard[e]}
    </div>
    `))},createFoldHoleCard=(e,a=!1)=>{const l=a?"#####":"####",i=GetUniqueID();let c="";e=(Object.entries(e)||[]).filter(e=>"string"!=typeof e[1]);e.sort(function(e,s){return e[1].sort-s[1].sort});let r='<div class="fold-hole">';return e.map(e=>{var s=e[0],d="string"==typeof e[1]?e[1]:e[1].value;e[1]?.fold?r+=`
      <div class="wmde-markdown fold-hole-title close" onclick="isOpenCardFun('${i}',${a})" id="${i}">
      <div class="extend-icon"></div>
      ${marked.parse(l+" ```"+d+"```")}
      </div>
      `:"code"===e[1]?.type?c+=`
              <div class="fold-hole-code">
                  <div class="title">${s}：${d?"":"-"}</div>
                  <div class="content">${d?marked.parse("```\n"+d+"\n```"):""}</div>
              </div>
            `:c+=`
          <div class="fold-hole-item">
              <div class="title">${s}：</div>
              <div class="content">${d||"-"}</div>
          </div>
          `}),cacheCard[i]=c,r+="</div>"},isOpenRiskCardFun=e=>{$("#"+e).hasClass("open")?($("#"+e).removeClass("open").addClass("close"),$("#"+e).nextAll(".rule-risk-box").css("display","none")):($("#"+e).removeClass("close").addClass("open"),$("#"+e).nextAll(".rule-risk-box").css("display","block"))},createruleRiskCard=e=>{var{data:e,title:s}=e,d=GetUniqueID();let a='<div class="rule-risk">';return s&&(a+=`<div class="wmde-markdown rule-risk-title close" onclick="isOpenRiskCardFun('${d}')" id="${d}">
    <div class="extend-icon"></div>  
    ${marked.parse(`#### ${s} (共${e.length}个)`)}</div>`),a+='<div class="rule-risk-box">',e.map(e=>{a+=createFoldHoleCard(e,!0)}),a+="</div></div>"},createEchartsCard=(e,s)=>{let d="";e.map(e=>{d+=`<div class="echarts-card-item">
              <div class="echarts-card-title">${e.key_verbose||e.key}</div>
              <div class="echarts-card-content">${e.value}</div>
              </div>`}),$("#content").append(`<div class="echarts-card-head">${s}</div><div class="echarts-card">${d}</div>`)};