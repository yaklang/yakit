const openDrawer=()=>{},initTable=t=>{t=JSON.parse(t);let a=`<table class="pure-table">
    <thead>
        <tr>`;return t?.header&&Array.isArray(t.header)&&t.header.map(t=>{a+=`<th>${t}</th>`}),a+=`</tr>
    </thead>
    <tbody>`,t?.data&&Array.isArray(t.data)&&t.data.map((t,e)=>{a+=`<tr ${e%2!=1?'class="pure-table-odd"':""}
      onclick="openDrawer()" 
      >`,Array.isArray(t)&&t.map(t=>{a+=`<td title="${t}">${t}</td>`}),a+="</tr>"}),a+=` </tbody>
    </table>`},initMergeTable=t=>{try{var e=JSON.parse(t),{header:a=[],data:r=[]}=(console.log("contentObj",e),e);let l={},o=(r.map(t=>{t[0]in l?l[t[0]]=[...l[t[0]],t.slice(1)]:l[t[0]]=[t.slice(1)]}),`<table class="pure-table">
    <thead>
        <tr>`);if(0<a.length&&a.map(t=>{o+=`<th>${t}</th>`}),o+=`</tr>
        </thead>
        <tbody>`,0<Object.keys(l).length){let r=!0,s=!0;Object.keys(l).forEach(function(a,t){Array.isArray(l[a])&&l[a].map((t,e)=>{o+=`<tr ${s?'class="pure-table-odd"':""} >`,s=!s,0===e&&(o+=`<td title="${a}" ${r?'class="row-pure-table-odd"':'class="row-pure-table-even"'} rowspan="${l[a].length}">${a}</td>`,r=!r),t.map(t=>{o+=`<td title="${t}">${t}</td>`}),o+="</tr>"})})}return o+=` </tbody>
        </table>`}catch(t){return console.error("initMergeTable:",t),""}},isOpenTableFun=(t,e)=>{$(`#${t}-`+e).hasClass("open")?($(`#${t}-`+e).removeClass("open").addClass("close"),$("#"+t).css("display","table-row")):($(`#${t}-`+e).removeClass("close").addClass("open"),$("#"+t).css("display","none"))};function GetUniqueID(){var t=Date.now().toString(36),e=Math.random().toString(36);return(e=e.substring(2,e.length))+t}const initExtendTable=e=>{var t=JSON.parse(e);let s=`<table class="pure-table">
    <thead>
        <tr>`;return t?.header&&Array.isArray(t.header)&&t.header.map(t=>{s+=`<th>${t}</th>`}),s+=`</tr>
    </thead>
    <tbody>`,t?.data&&Array.isArray(t.data)&&t.data.map((t,a)=>{const r=GetUniqueID();s+=`<tr ${a%2!=1?'class="pure-table-hover pure-table-odd"':'class="pure-table-hover"'} onclick="isOpenTableFun('${r}',${a})">`,Array.isArray(t)&&t.map((t,e)=>{s+=0===e?`<td>
          <a id="${r}-${a}" class="open"></a>
          <span style="padding-left:20px">${t}</span>
          </td>`:`<td>${t}</td>`}),s=(s+="</tr>")+`<tr id="${r}" style="border: 1px solid #cbcbcb;display:none;">
                      <th colspan="4">`+initTable(e)+`</th>
                   </tr>`}),s+=` </tbody>
    </table>`},goNewPageByIp=t=>{let e=window.location.href.replace(window.location.hash,"");e+=(-1===e.indexOf("?")?"?":"&")+"jump_link="+t,window.open(e)},createRistListTable=t=>{let r=[],s=[],l=(Array.isArray(t.data)&&t.data.map((t,e)=>{t=Object.entries(t);t.sort(function(t,e){return t[1].sort-e[1].sort});let a=[];t.map(t=>{0===e&&r.push(t[0]),a.push(t[1])}),s.push(a)}),`<table class="pure-table">
    <thead>
        <tr>`);return r.map(t=>{l+=`<th>${t}</th>`}),l+=`</tr>
    </thead>
    <tbody>`,s.map((t,e)=>{l+=`<tr ${e%2!=1?'class="pure-table-odd"':""}>`,Array.isArray(t)&&t.map(t=>{var{jump_link:t,color:e,value:a}=t;l+=`<td
         ${t?`onclick="goNewPageByIp('${t}')"`:""}
         style="${e?`color:${e};`:""}
         ${t?"cursor: pointer;":""}"
         >${a}</td>`}),l+="</tr>"}),l+=` </tbody>
    </table>`};