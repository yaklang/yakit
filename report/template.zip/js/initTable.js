const openDrawer=()=>{},initTable=t=>{t=JSON.parse(t);let e=`<table class="pure-table">
    <thead>
        <tr>`;return t?.header&&Array.isArray(t.header)&&t.header.map(t=>{e+=`<th>${t}</th>`}),e+=`</tr>
    </thead>
    <tbody>`,t?.data&&Array.isArray(t.data)&&t.data.map((t,a)=>{e+=`<tr ${a%2!=1?'class="pure-table-odd"':""}
      onclick="openDrawer()" 
      >`,Array.isArray(t)&&t.map(t=>{e+=`<td title="${t}">${t}</td>`}),e+="</tr>"}),e+=` </tbody>
    </table>`},initMergeTable=t=>{try{var a=JSON.parse(t),{header:e=[],data:l=[]}=a;let r={},s=(l.map(t=>{t[0]in r?r[t[0]]=[...r[t[0]],t.slice(1)]:r[t[0]]=[t.slice(1)]}),`<table class="pure-table">
    <thead>
        <tr>`);return 0<e.length&&e.map(t=>{s+=`<th>${t}</th>`}),s+=`</tr>
        </thead>
        <tbody>`,0<Object.keys(r).length&&Object.keys(r).forEach(function(e,t){Array.isArray(r[e])&&r[e].map((t,a)=>{s+=`<tr ${a%2!=1?'class="pure-table-odd"':""} >`,0===a&&(s+=`<td title="${e}" rowspan="${r[e].length}">${e}</td>`),t.map(t=>{s+=`<td title="${t}">${t}</td>`}),s+="</tr>"})}),s+=` </tbody>
        </table>`}catch(t){return console.error("initMergeTable:",t),""}},isOpenTableFun=(t,a)=>{$(`#${t}-`+a).hasClass("open")?($(`#${t}-`+a).removeClass("open").addClass("close"),$("#"+t).css("display","table-row")):($(`#${t}-`+a).removeClass("close").addClass("open"),$("#"+t).css("display","none"))};function GetUniqueID(){var t=Date.now().toString(36),a=Math.random().toString(36);return(a=a.substring(2,a.length))+t}const initExtendTable=a=>{var t=JSON.parse(a);let s=`<table class="pure-table">
    <thead>
        <tr>`;return t?.header&&Array.isArray(t.header)&&t.header.map(t=>{s+=`<th>${t}</th>`}),s+=`</tr>
    </thead>
    <tbody>`,t?.data&&Array.isArray(t.data)&&t.data.map((t,e)=>{const r=GetUniqueID();s+=`<tr ${e%2!=1?'class="pure-table-hover pure-table-odd"':'class="pure-table-hover"'} onclick="isOpenTableFun('${r}',${e})">`,Array.isArray(t)&&t.map((t,a)=>{s+=0===a?`<td>
          <a id="${r}-${e}" class="open"></a>
          <span style="padding-left:20px">${t}</span>
          </td>`:`<td>${t}</td>`}),s=(s+="</tr>")+`<tr id="${r}" style="border: 1px solid #cbcbcb;display:none;">
                      <th colspan="4">`+initTable(a)+`</th>
                   </tr>`}),s+=` </tbody>
    </table>`},goNewPageByIp=t=>{let a=window.location.href.replace(window.location.hash,"");a+=(-1===a.indexOf("?")?"?":"&")+"jump_link="+t,window.open(a)},createRistListTable=t=>{let r=[],s=[],l=(Array.isArray(t.data)&&t.data.map((t,a)=>{t=Object.entries(t);t.sort(function(t,a){return t[1].sort-a[1].sort});let e=[];t.map(t=>{0===a&&r.push(t[0]),e.push(t[1])}),s.push(e)}),`<table class="pure-table">
    <thead>
        <tr>`);return r.map(t=>{l+=`<th>${t}</th>`}),l+=`</tr>
    </thead>
    <tbody>`,s.map((t,a)=>{l+=`<tr ${a%2!=1?'class="pure-table-odd"':""}>`,Array.isArray(t)&&t.map(t=>{var{jump_link:t,color:a,value:e}=t;l+=`<td
         ${t?`onclick="goNewPageByIp('${t}')"`:""}
         style="${a?`color:${a};`:""}
         ${t?"cursor: pointer;":""}"
         >${e}</td>`}),l+="</tr>"}),l+=` </tbody>
    </table>`};