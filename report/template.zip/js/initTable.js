const openDrawer=()=>{},initTable=a=>{a=JSON.parse(a);let e=`<table class="pure-table">
    <thead>
        <tr>`;return a?.header&&Array.isArray(a.header)&&a.header.map(a=>{e+=`<th>${a}</th>`}),e+=`</tr>
    </thead>
    <tbody>`,a?.data&&Array.isArray(a.data)&&a.data.map((a,t)=>{e+=`<tr ${t%2!=1?'class="pure-table-odd"':""}
      onclick="openDrawer()" 
      >`,Array.isArray(a)&&a.map(a=>{e+=`<td title="${a}">${a}</td>`}),e+="</tr>"}),e+=` </tbody>
    </table>`},initMergeTable=a=>{try{let r=[],l=[],s=(Array.isArray(a.data)&&a.data.map((a,t)=>{a=Object.entries(a);a.sort(function(a,t){return a[1].sort-t[1].sort});let e=[];a.map(a=>{0===t&&r.push(a[0]),e.push(a[1]?.value||"")}),l.push(e)}),{}),o=(l.map(a=>{a[0]in s?s[a[0]]=[...s[a[0]],a.slice(1)]:s[a[0]]=[a.slice(1)]}),`<table class="pure-table">
    <thead>
        <tr>`);if(0<r.length&&r.map(a=>{o+=`<th>${a}</th>`}),o+=`</tr>
        </thead>
        <tbody>`,0<Object.keys(s).length){let r=!0,l=!0;Object.keys(s).forEach(function(e,a){Array.isArray(s[e])&&s[e].map((a,t)=>{o+=`<tr ${l?'class="pure-table-odd"':""} >`,l=!l,0===t&&(o+=`<td title="${e}" ${r?'class="row-pure-table-odd"':'class="row-pure-table-even"'} rowspan="${s[e].length}">${e}</td>`,r=!r),a.map(a=>{o+=`<td title="${a}">${a}</td>`}),o+="</tr>"})})}return o+=` </tbody>
        </table>`}catch(a){return console.error("initMergeTable:",a),""}};function GetUniqueID(){var a=Date.now().toString(36),t=Math.random().toString(36);return(t=t.substring(2,t.length))+a}let FoldTableData=[];const isOpenFoldTableFun=a=>{if($("#"+a).hasClass("fold-open")){let e="<tbody>";FoldTableData&&Array.isArray(FoldTableData)&&FoldTableData.map((a,t)=>{e+=`<tr ${t%2!=1?'class="pure-table-odd"':""}
        onclick="openDrawer()" 
        >`,Array.isArray(a)&&a.map(a=>{e+=`<td title="${a}">${a}</td>`}),e+="</tr>"}),e+="</tbody>",$("#"+a).removeClass("fold-open").addClass("fold-close"),$(`#${a}-thead`).after($(e))}else $("#"+a).removeClass("fold-close").addClass("fold-open"),$(`#${a}-thead`).next().remove()},initFoldTable=a=>{let r=[];Array.isArray(a.data)&&a.data.map((a,t)=>{a=Object.entries(a);a.sort(function(a,t){return a[1].sort-t[1].sort});let e=[];a.map(a=>{0===t&&r.push(a[0]),e.push(a[1]?.value||"")}),FoldTableData.push(e)});const e=GetUniqueID();let l=`<table class="pure-table">
    <thead id="${e}-thead" onclick="isOpenFoldTableFun('${e}')" style="cursor: pointer;">
        <tr>`;return r&&Array.isArray(r)&&r.map((a,t)=>{l+=0===t?`<th style="position: relative;">
      <a id="${e}" class="fold-open"></a>
      <span >${a}</span>
      </th>`:`<th>${a}</th>`}),l=l+`</tr>
    </thead>`+" </table>"},isOpenTableFun=(a,t)=>{$(`#${a}-`+t).hasClass("open")?($(`#${a}-`+t).removeClass("open").addClass("close"),$("#"+a).css("display","table-row")):($(`#${a}-`+t).removeClass("close").addClass("open"),$("#"+a).css("display","none"))},initExtendTable=t=>{var a=JSON.parse(t);let l=`<table class="pure-table">
    <thead>
        <tr>`;return a?.header&&Array.isArray(a.header)&&a.header.map(a=>{l+=`<th>${a}</th>`}),l+=`</tr>
    </thead>
    <tbody>`,a?.data&&Array.isArray(a.data)&&a.data.map((a,e)=>{const r=GetUniqueID();l+=`<tr ${e%2!=1?'class="pure-table-hover pure-table-odd"':'class="pure-table-hover"'} onclick="isOpenTableFun('${r}',${e})">`,Array.isArray(a)&&a.map((a,t)=>{l+=0===t?`<td>
          <a id="${r}-${e}" class="open"></a>
          <span style="padding-left:20px">${a}</span>
          </td>`:`<td>${a}</td>`}),l=(l+="</tr>")+`<tr id="${r}" style="border: 1px solid #cbcbcb;display:none;">
                      <th colspan="4">`+initTable(t)+`</th>
                   </tr>`}),l+=` </tbody>
    </table>`},goNewPageByIp=a=>{let t=window.location.href.replace(window.location.hash,"");t+=(-1===t.indexOf("?")?"?":"&")+"jump_link="+a,window.open(t)},createRistListTable=a=>{let r=[],l=[],s=(Array.isArray(a.data)&&a.data.map((a,t)=>{a=Object.entries(a);a.sort(function(a,t){return a[1].sort-t[1].sort});let e=[];a.map(a=>{0===t&&r.push(a[0]),e.push(a[1])}),l.push(e)}),`<table class="pure-table">
    <thead>
        <tr>`);return r.map(a=>{s+=`<th>${a}</th>`}),s+=`</tr>
    </thead>
    <tbody>`,l.map((a,t)=>{s+=`<tr ${t%2!=1?'class="pure-table-odd"':""}>`,Array.isArray(a)&&a.map(a=>{var{jump_link:a,color:t,value:e}=a;s+=`<td
         ${a?`onclick="goNewPageByIp('${a}')"`:""}
         style="${t?`color:${t};`:""}
         ${a?"cursor: pointer;":""}"
         >${e}</td>`}),s+="</tr>"}),s+=` </tbody>
    </table>`};