let tocItems = [];
let tocifyIndex = 0;

const tocifyAdd = (text, level) => {
  if (level <= 4) {
    //标签过小不予展示
    const anchor = `toc${level}${++tocifyIndex}`;
    const item = { anchor, level, text };
    const items = tocItems;

    if (items.length === 0) {
      // 第一个 item 直接 push
      items.push(item);
    } else {
      let lastItem = items.slice(-1); // 最后一个 item

      if (item.level > lastItem.level) {
        // item 是 lastItem 的 children
        for (let i = lastItem.level + 1; i <= 2; i++) {
          const { children } = lastItem;
          if (!children) {
            // 如果 children 不存在
            lastItem.children = [item];
            break;
          }

          lastItem = children.slice(-1); // 重置 lastItem 为 children 的最后一个 item

          if (item.level <= lastItem.level) {
            // item level 小于或等于 lastItem level 都视为与 children 同级
            children.push(item);
            break;
          }
        }
      } else {
        // 置于最顶级
        items.push(item);
      }
    }

    return anchor;
  }
};

const isOpenBarFun = (id, index) => {
  const openStatus = $(`#${id}-${index}`).hasClass("open");
  // open点击展开 close点击关闭
  if (openStatus) {
    $(`#${id}-${index}`).removeClass("open").addClass("close");
    $(`.${id}`).css("display", "block");
  } else {
    $(`#${id}-${index}`).removeClass("close").addClass("open");
    $(`.${id}`).css("display", "none");
  }
};

reset = () => {
  tocItems = [];
  tocifyIndex = 0;
};

const renderToc = (items) => {
  // 递归 render
  reset();
  // 展开level记录---用于分割
  let extendLevel = null
  // 需要隐藏项的class
  let extendLevelClass = ""
  return items.map((item, index) => {
    const onlyId = GetUniqueID();
    // 导航栏折叠
    if ((item?.text || "").search("危漏洞详情") >= 0) {
      extendLevel = item.level
      extendLevelClass = `${onlyId}`
      return `<div class="level-${item.level} extend">
      <a id="${onlyId}-${index}" class="open"
      onclick="isOpenBarFun('${onlyId}',${index})"></a>
        <a href="#${item.anchor}" class="content">
            ${item.text}
            ${item?.children ? renderToc(item.children) : ""}
        </a>
        </div>`;
    } else {
      // 折叠项判断
      if(extendLevel&&(extendLevel<item.level)){
        return `<div class="level-${item.level} ${extendLevelClass}" style="display:none;">
        <a href="#${item.anchor}">
            ${item.text}
            ${item?.children ? renderToc(item.children) : ""}
        </a>
        </div>`;
      }
      if(extendLevel&&(extendLevel>=item.level)){
        extendLevel = null
      }
      return `<div class="level-${item.level}">
        <a href="#${item.anchor}">
            ${item.text}
            ${item?.children ? renderToc(item.children) : ""}
        </a>
        </div>`;
    }
  });
};
