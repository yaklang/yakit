#!/bin/bash

cd $(dirname $0)
# 证书文件路径
CERT_FILE="yak-mitm-ca.crt"

# 检查证书文件是否存在
if [ ! -f "$CERT_FILE" ]; then
    echo -e "\033[31mError: Certificate file '$CERT_FILE' not found.\033[0m"
    read -p "Press Enter to exit"
    exit 1
fi

# Linux 发行版证书安装函数
install_linux_cert() {
    local install_cmd="$1"
    local cert_folder="$2"
    local update_cmd="$3"
    local distro_name="$4"
    
    echo -e "\033[36mDetected Linux distribution: $distro_name\033[0m"
    
    # 检查证书更新工具是否已安装
    local cert_update_tool=$(echo $update_cmd | awk '{print $1}')
    local need_install=0
    
    echo -e "\033[36mChecking certificate management tools...\033[0m"
    
    if command -v $cert_update_tool >/dev/null 2>&1; then
        echo -e "\033[32m✓ Certificate update tool ($cert_update_tool) is already installed\033[0m"
    else
        echo -e "\033[33m! Certificate update tool ($cert_update_tool) is not installed\033[0m"
        need_install=1
    fi
    

    
    # 只有在需要时才安装工具
    if [ $need_install -eq 1 ]; then
        echo -e "\033[36mInstalling required certificate management tools...\033[0m"
        eval "sudo $install_cmd" || {
            echo -e "\033[31mFailed to install certificate management tools.\033[0m"
            return 1
        }
        echo -e "\033[32m✓ Certificate management tools installed successfully\033[0m"
    else
        echo -e "\033[32m✓ All required tools are already available\033[0m"
    fi
    
    # 检查并创建证书目录
    if [ -d "$cert_folder" ]; then
        echo -e "\033[32m✓ Certificate directory already exists: $cert_folder\033[0m"
    else
        echo -e "\033[36mCreating certificate directory: $cert_folder\033[0m"
        sudo mkdir -p "$cert_folder" || {
            echo -e "\033[31mFailed to create certificate directory.\033[0m"
            return 1
        }
    fi
    
    # 检查证书是否已经存在
    local cert_name=$(basename "$CERT_FILE")
    if [ -f "$cert_folder/$cert_name" ]; then
        echo -e "\033[33m! Certificate '$cert_name' already exists in $cert_folder\033[0m"
        echo -e "\033[36mBacking up existing certificate...\033[0m"
        sudo cp "$cert_folder/$cert_name" "$cert_folder/${cert_name}.backup.$(date +%Y%m%d_%H%M%S)" || true
    fi
    
    # 复制证书文件到指定目录
    echo -e "\033[36mCopying certificate to $cert_folder/\033[0m"
    sudo cp "$CERT_FILE" "$cert_folder/" || {
        echo -e "\033[31mFailed to copy certificate file.\033[0m"
        return 1
    }
    echo -e "\033[32m✓ Certificate copied successfully\033[0m"
    
    # 更新证书存储
    echo -e "\033[36mUpdating certificate store...\033[0m"
    eval "sudo $update_cmd" || {
        echo -e "\033[31mFailed to update certificate store.\033[0m"
        return 1
    }
    
    return 0
}

# 检查操作系统类型
OS=$(uname)
if [ "$OS" == "Darwin" ]; then
    # macOS 上的证书存储路径
    echo -e "\033[36mDetected macOS system\033[0m"
    CERT_STORE="/Library/Keychains/System.keychain"
    sudo security add-trusted-cert -d -r trustRoot -k "$CERT_STORE" "$CERT_FILE"
    INSTALL_SUCCESS=$?
elif [ "$OS" == "Linux" ]; then
    # 识别Linux发行版并选择相应的安装方法
    if grep -q "Alpine Linux" /etc/*-release 2>/dev/null; then
        install_linux_cert "apk add ca-certificates" "/usr/local/share/ca-certificates" "update-ca-certificates" "Alpine Linux"
        INSTALL_SUCCESS=$?
    elif grep -q "Amazon Linux" /etc/*-release 2>/dev/null; then
        install_linux_cert "yum install -y ca-certificates" "/etc/pki/ca-trust/source/anchors/" "update-ca-trust extract" "Amazon Linux"
        INSTALL_SUCCESS=$?
    elif grep -q "Arch Linux" /etc/*-release 2>/dev/null; then
        install_linux_cert "pacman -Sy --noconfirm ca-certificates-utils" "/etc/ca-certificates/trust-source/anchors/" "trust extract-compat" "Arch Linux"
        INSTALL_SUCCESS=$?
    elif grep -q "CentOS" /etc/*-release 2>/dev/null; then
        install_linux_cert "yum install -y ca-certificates" "/etc/pki/ca-trust/source/anchors/" "update-ca-trust extract" "CentOS"
        INSTALL_SUCCESS=$?
    elif grep -q "Debian" /etc/*-release 2>/dev/null; then
        install_linux_cert "apt-get update && apt-get install -y ca-certificates" "/usr/local/share/ca-certificates/" "update-ca-certificates" "Debian"
        INSTALL_SUCCESS=$?
    elif grep -q "Fedora" /etc/*-release 2>/dev/null; then
        install_linux_cert "dnf install -y ca-certificates" "/etc/pki/ca-trust/source/anchors/" "update-ca-trust extract" "Fedora"
        INSTALL_SUCCESS=$?
    elif grep -q "Red Hat" /etc/*-release 2>/dev/null; then
        install_linux_cert "yum install -y ca-certificates" "/etc/pki/ca-trust/source/anchors/" "update-ca-trust extract" "Red Hat Enterprise Linux"
        INSTALL_SUCCESS=$?
    elif grep -q "SUSE" /etc/*-release 2>/dev/null; then
        install_linux_cert "zypper install -y ca-certificates" "/etc/pki/trust/anchors/" "update-ca-certificates" "SUSE Linux"
        INSTALL_SUCCESS=$?
    elif grep -q "Ubuntu" /etc/*-release 2>/dev/null; then
        install_linux_cert "apt-get update && apt-get install -y ca-certificates" "/usr/local/share/ca-certificates/" "update-ca-certificates" "Ubuntu"
        INSTALL_SUCCESS=$?
    else
        # 通用Linux处理（尝试检测包管理器）
        echo -e "\033[33mUnrecognized Linux distribution, attempting generic installation...\033[0m"
        if command -v apt-get >/dev/null 2>&1; then
            install_linux_cert "apt-get update && apt-get install -y ca-certificates" "/usr/local/share/ca-certificates/" "update-ca-certificates" "Generic Debian-based"
            INSTALL_SUCCESS=$?
        elif command -v yum >/dev/null 2>&1; then
            install_linux_cert "yum install -y ca-certificates" "/etc/pki/ca-trust/source/anchors/" "update-ca-trust extract" "Generic RedHat-based"
            INSTALL_SUCCESS=$?
        elif command -v dnf >/dev/null 2>&1; then
            install_linux_cert "dnf install -y ca-certificates" "/etc/pki/ca-trust/source/anchors/" "update-ca-trust extract" "Generic Fedora-based"
            INSTALL_SUCCESS=$?
        elif command -v zypper >/dev/null 2>&1; then
            install_linux_cert "zypper install -y ca-certificates" "/etc/pki/trust/anchors/" "update-ca-certificates" "Generic SUSE-based"
            INSTALL_SUCCESS=$?
        elif command -v apk >/dev/null 2>&1; then
            install_linux_cert "apk add ca-certificates" "/usr/local/share/ca-certificates" "update-ca-certificates" "Generic Alpine-based"
            INSTALL_SUCCESS=$?
        elif command -v pacman >/dev/null 2>&1; then
            install_linux_cert "pacman -Sy --noconfirm ca-certificates-utils" "/etc/ca-certificates/trust-source/anchors/" "trust extract-compat" "Generic Arch-based"
            INSTALL_SUCCESS=$?
        else
            echo -e "\033[31mUnsupported Linux distribution: No recognized package manager found.\033[0m"
            echo -e "\033[33mPlease manually install the certificate using your distribution's method.\033[0m"
            INSTALL_SUCCESS=1
        fi
    fi
else
    echo -e "\033[31mUnsupported operating system: $OS\033[0m"
    INSTALL_SUCCESS=1
fi

# 检查安装结果
if [ $INSTALL_SUCCESS -eq 0 ]; then
    echo -e "\033[32m✓ Certificate successfully installed and trusted.\033[0m"
    echo -e "\033[36mNote: You may need to restart applications to use the new certificate.\033[0m"
else
    echo -e "\033[31m✗ Failed to install certificate.\033[0m"
    echo -e "\033[33mPlease check the error messages above and try manual installation.\033[0m"
fi

read -p "Press Enter to exit"