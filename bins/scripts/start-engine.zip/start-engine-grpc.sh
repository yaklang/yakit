#!/bin/bash
set +x
cd $(pwd) &
./yak grpc